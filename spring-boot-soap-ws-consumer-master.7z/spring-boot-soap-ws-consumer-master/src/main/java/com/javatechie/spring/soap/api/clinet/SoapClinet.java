package com.javatechie.spring.soap.api.clinet;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceTemplate;

import com.javatechie.spring.soap.api.loaneligibility.Acknowledgement;
import com.javatechie.spring.soap.api.loaneligibility.CustomerRequest;
import com.javatechie.spring.soap.api.service.RabbitMQSender;

@Service
public class SoapClinet {

	@Autowired
	private Jaxb2Marshaller marshaller;

	private WebServiceTemplate template;
	
	@Autowired
	RabbitMQSender rabbitMQSender;

	public Acknowledgement getLoanStatus(CustomerRequest request) {
		template = new WebServiceTemplate(marshaller);
		Acknowledgement acknowledgement = (Acknowledgement) template.marshalSendAndReceive("http://localhost:8080/ws",
				request);
		System.out.println("acknowledgement :::::::::"+acknowledgement.getApprovedAmount());
			    
		 String xml = convert(acknowledgement, "root"); 
	     
		System.out.println("xml formate si :::::::::::::"+xml);
		
		rabbitMQSender.send(xml);
		
		System.out.println("=========== succesfully send the message to rabbitmq =========");
		return acknowledgement;
	}
	 public static String convert(Acknowledgement json, String root) throws JSONException {
	      JSONObject jsonObject = new JSONObject(json);
	      String xml = "<?xml version=\"1.0\" encoding=\"ISO-8859-15\"?>\n<"+root+">" + XML.toString(jsonObject) + "</"+root+">";
	      return xml;
	   }

}
